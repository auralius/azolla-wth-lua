
#ifndef __LUA_INC_H__
#define __LUA_INC_H__

extern "C"
{
   #include "lua.h"
   #include "lauxlib.h"
   #include "lualib.h"
}

#endif // __LUA_INC_H__
' String"
Dim a As String = "hello, world"
Dim b As String = "hello    world"
Dim c As String = "Joe said ""Hello"" to me"
Dim d As String = "\\\\server\\share\\file.txt"
' Character
""C "c"C "cc"C
' Date
d = #5/31/1993# or # 01/01/0001 12:00:00AM #
